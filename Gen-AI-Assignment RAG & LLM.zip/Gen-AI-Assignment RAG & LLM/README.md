# Applied AI/ML Engineering — Take-Home Assignment

Two independent, runnable projects:

| Folder | Problem | What it is |
|---|---|---|
| `problem1_rag/` | Cost-Efficient RAG Application | FastAPI QA service over documents, backed by ChromaDB, with a full retrieval+answer+cost evaluation harness |
| `problem2_judge/` | LLM-as-Judge Evaluation Pipeline | A judging pipeline with structured verdicts, position-bias mitigation, and judge validation |

Each folder is self-contained: its own `requirements.txt`, `.env.example`, and `README.md` with
setup + run instructions + results + discussion. Start with each subfolder's README.

## Global design decisions (apply to both)

- **LLM**: Anthropic Claude (`claude-sonnet-5` for generation/judging by default, configurable via `.env`).
  Anthropic does not expose an embeddings endpoint, so:
- **Embeddings**: `sentence-transformers/all-MiniLM-L6-v2` (384-dim, local, free, no extra API key).
  This is recorded explicitly in Problem 1's README as required by the spec ("record model +
  dimensionality"). Swapping to Voyage AI (Anthropic's recommended embeddings partner) or OpenAI
  embeddings is a one-line change in `rag/embeddings.py` / `judge` config if you have those keys.
- Both projects read all config (API keys, model names, chunk sizes, thresholds) from environment
  variables via `.env` — nothing is hardcoded.

## Quick start

```bash
cd problem1_rag && pip install -r requirements.txt && cp .env.example .env  # add your ANTHROPIC_API_KEY
python ingest.py --input data/
uvicorn app:app --reload --port 8000

cd ../problem2_judge && pip install -r requirements.txt && cp .env.example .env
python pipeline.py --suite test_suite.json --out results/report.json
```
