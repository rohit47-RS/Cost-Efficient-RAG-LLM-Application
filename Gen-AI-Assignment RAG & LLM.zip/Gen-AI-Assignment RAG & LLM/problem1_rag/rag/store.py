"""
ChromaDB (embedded, persistent, local disk) vector store wrapper.

Why ChromaDB (the "pick one store" choice, per the assignment):
- Embedded / self-hosted: runs in-process, persists to a local directory — no always-on
  pod or managed service bill, which is the entire cost thesis of this assignment.
- Native metadata filtering (`where=...`) out of the box, satisfying the "at least one
  metadata filter" requirement without extra plumbing.
- Simple upsert semantics that map directly onto our idempotent-chunk-id design.
- Good enough ANN performance (HNSW under the hood) at the 100K-vector scale this
  assignment's cost table targets; see README Discussion for where this stops being true.

Idempotency: chunk_id is a deterministic hash of (doc_id, chunk_index, content). We
upsert by id, so re-ingesting an unchanged document overwrites the same ids (no
duplicates). We also delete-then-insert per doc_id when a document's chunk *count*
changes (e.g. it got shorter), so stale trailing chunks from a previous version don't
linger — see `upsert_document`.
"""
from __future__ import annotations
from dataclasses import dataclass

import chromadb
from chromadb.config import Settings as ChromaSettings

from rag.chunking import Chunk
from rag.embeddings import embed_texts


@dataclass
class RetrievedChunk:
    chunk_id: str
    text: str
    metadata: dict
    score: float  # similarity score, higher = more relevant


class VectorStore:
    def __init__(self, persist_dir: str, collection_name: str):
        self.client = chromadb.PersistentClient(
            path=persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )

    def upsert_document(self, doc_id: str, chunks: list[Chunk]) -> int:
        """Idempotent re-ingest for a single document: remove any existing chunks for
        this doc_id, then insert the current set. Safe to call repeatedly on an
        unchanged file (chunk_ids are stable -> effectively a no-op overwrite) and
        correct when a file changes (old chunk count != new chunk count)."""
        existing = self.collection.get(where={"doc_id": doc_id})
        if existing and existing.get("ids"):
            self.collection.delete(ids=existing["ids"])

        if not chunks:
            return 0

        embeddings = embed_texts([c.text for c in chunks])
        self.collection.upsert(
            ids=[c.chunk_id for c in chunks],
            embeddings=embeddings.tolist(),
            documents=[c.text for c in chunks],
            metadatas=[c.metadata for c in chunks],
        )
        return len(chunks)

    def query(self, query_text: str, top_k: int, where: dict | None = None) -> list[RetrievedChunk]:
        query_emb = embed_texts([query_text])
        result = self.collection.query(
            query_embeddings=query_emb.tolist(),
            n_results=top_k,
            where=where,
        )
        out: list[RetrievedChunk] = []
        ids = result.get("ids", [[]])[0]
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        dists = result.get("distances", [[]])[0]
        for cid, doc, meta, dist in zip(ids, docs, metas, dists):
            # Chroma cosine "distance" = 1 - cosine_similarity; convert back to similarity.
            similarity = 1.0 - dist
            out.append(RetrievedChunk(chunk_id=cid, text=doc, metadata=meta, score=similarity))
        return out

    def count(self) -> int:
        return self.collection.count()
