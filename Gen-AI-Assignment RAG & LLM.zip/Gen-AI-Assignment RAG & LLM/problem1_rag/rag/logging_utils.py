"""Structured, greppable per-query logging: latency, chunk count, token usage."""
from __future__ import annotations
import json
import logging
import time
from pathlib import Path

log = logging.getLogger("rag.query")

QUERY_LOG_PATH = Path("logs/queries.jsonl")


def log_query(
    question: str,
    top_k: int,
    retrieval_latency_ms: float,
    generation_latency_ms: float,
    num_chunks_retrieved: int,
    num_chunks_cited: int,
    input_tokens: int,
    output_tokens: int,
    used_no_context_fallback: bool,
) -> dict:
    record = {
        "ts": time.time(),
        "question": question,
        "top_k": top_k,
        "retrieval_latency_ms": round(retrieval_latency_ms, 2),
        "generation_latency_ms": round(generation_latency_ms, 2),
        "total_latency_ms": round(retrieval_latency_ms + generation_latency_ms, 2),
        "num_chunks_retrieved": num_chunks_retrieved,
        "num_chunks_cited": num_chunks_cited,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "used_no_context_fallback": used_no_context_fallback,
    }
    log.info(json.dumps(record))

    QUERY_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with QUERY_LOG_PATH.open("a") as f:
        f.write(json.dumps(record) + "\n")

    return record
