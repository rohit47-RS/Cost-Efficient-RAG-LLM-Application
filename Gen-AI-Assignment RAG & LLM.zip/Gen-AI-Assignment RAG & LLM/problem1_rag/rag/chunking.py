"""
Loading PDF/HTML/MD files and splitting into overlapping, token-aware chunks.

Chunking strategy: sliding window over whitespace tokens, splitting on paragraph
boundaries when possible so we don't cut a sentence in half more than necessary.
Defaults: 350 tokens / 60 overlap (configurable via CHUNK_SIZE_TOKENS /
CHUNK_OVERLAP_TOKENS) — small enough to keep retrieval precise, with enough overlap
that an answer spanning a paragraph boundary isn't split across two chunks with no
shared context.

Tokenizer note: we use a whitespace tokenizer (1 token ~= 1 word) rather than a
model-specific BPE tokenizer (e.g. tiktoken). This is a deliberate simplification:
it avoids a runtime dependency on downloading a remote BPE vocab file (tiktoken's
cl100k_base file is fetched from an OpenAI-hosted blob on first use, an easy-to-miss
external dependency for an Anthropic-model pipeline, and one that fails in
network-locked environments), and "350 words" is close enough to "350 GPT tokens"
(~0.75 tokens/word) for chunk-sizing purposes — this is tuning a retrieval
hyperparameter, not counting billable tokens. Billable token counts for generation
come from the Anthropic API's own `usage` field (see rag/generation.py).
"""
from __future__ import annotations
import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

from bs4 import BeautifulSoup
from pypdf import PdfReader


def _tokenize(text: str) -> list[str]:
    """Whitespace tokenizer. Good enough for windowing purposes."""
    return text.split()


def _detokenize(tokens: list[str]) -> str:
    return " ".join(tokens)


@dataclass
class Chunk:
    chunk_id: str          # stable hash: doc_id + position + content hash (idempotency key)
    doc_id: str
    source_path: str
    text: str
    chunk_index: int
    token_count: int
    metadata: dict


def _load_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix in (".html", ".htm"):
        soup = BeautifulSoup(path.read_text(encoding="utf-8", errors="ignore"), "html.parser")
        for tag in soup(["script", "style"]):
            tag.decompose()
        return soup.get_text(separator="\n")
    if suffix in (".md", ".markdown", ".txt"):
        return path.read_text(encoding="utf-8", errors="ignore")
    raise ValueError(f"Unsupported file type: {suffix} ({path})")


def _split_paragraphs(text: str) -> list[str]:
    paras = re.split(r"\n\s*\n", text)
    return [p.strip() for p in paras if p.strip()]


def _doc_id_for(path: Path) -> str:
    """Stable id derived from the file path (not content) so re-ingesting the same
    logical document always maps to the same doc_id, enabling delete-before-insert
    idempotency in the store layer."""
    return hashlib.sha1(str(path.resolve()).encode()).hexdigest()[:16]


def chunk_document(path: Path, chunk_size_tokens: int, overlap_tokens: int) -> list[Chunk]:
    """Load one file and split it into token-windowed chunks.

    Idempotency contract: chunk_id = sha1(doc_id + chunk_index + text) so re-running
    ingestion on an unchanged file yields byte-identical chunk_ids -> upsert is a no-op
    duplicate-free overwrite, not an append.
    """
    doc_id = _doc_id_for(path)
    raw_text = _load_text(path)
    paragraphs = _split_paragraphs(raw_text)

    # Flatten paragraphs into one token stream with paragraph boundaries marked,
    # then window over tokens so chunk_size_tokens is respected exactly.
    all_tokens: list[str] = []
    for para in paragraphs:
        all_tokens.extend(_tokenize(para))
        all_tokens.append("\n\n")  # paragraph-boundary marker, collapsed back on join

    if not all_tokens:
        return []

    chunks: list[Chunk] = []
    step = max(chunk_size_tokens - overlap_tokens, 1)
    idx = 0
    chunk_index = 0
    while idx < len(all_tokens):
        window = all_tokens[idx: idx + chunk_size_tokens]
        text = _detokenize(window).replace(" \n\n ", "\n\n").strip()
        if text:
            content_hash = hashlib.sha1(text.encode()).hexdigest()[:12]
            chunk_id = f"{doc_id}_{chunk_index}_{content_hash}"
            chunks.append(Chunk(
                chunk_id=chunk_id,
                doc_id=doc_id,
                source_path=str(path),
                text=text,
                chunk_index=chunk_index,
                token_count=len(window),
                metadata={
                    "source": path.name,
                    "doc_id": doc_id,
                    "chunk_index": chunk_index,
                    "file_type": path.suffix.lower().lstrip("."),
                },
            ))
            chunk_index += 1
        idx += step
    return chunks


def chunk_directory(input_dir: Path, chunk_size_tokens: int, overlap_tokens: int) -> list[Chunk]:
    exts = {".pdf", ".html", ".htm", ".md", ".markdown", ".txt"}
    files = sorted(p for p in input_dir.rglob("*") if p.suffix.lower() in exts and p.is_file())
    all_chunks: list[Chunk] = []
    for f in files:
        all_chunks.extend(chunk_document(f, chunk_size_tokens, overlap_tokens))
    return all_chunks
