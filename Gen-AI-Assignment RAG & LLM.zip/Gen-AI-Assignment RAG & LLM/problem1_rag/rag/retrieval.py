"""Top-k retrieval, with optional metadata filter (e.g. {"file_type": "pdf"})."""
from __future__ import annotations
from rag.store import VectorStore, RetrievedChunk


def retrieve(store: VectorStore, query: str, top_k: int, metadata_filter: dict | None = None) -> list[RetrievedChunk]:
    return store.query(query_text=query, top_k=top_k, where=metadata_filter)
