"""
Grounded answer generation: given a question + retrieved chunks, produce an answer
that only uses the provided context, cites which chunk(s) it drew from by id, and
explicitly says it doesn't know rather than hallucinating when nothing relevant
was retrieved.
"""
from __future__ import annotations
import json
import time
from dataclasses import dataclass, field

import anthropic

from rag.store import RetrievedChunk

NO_CONTEXT_SENTINEL = "I don't have enough information in the provided documents to answer this."

# Below this similarity score we treat retrieval as "nothing relevant" even if Chroma
# returned k results (it always returns up to k nearest neighbors, relevant or not).
MIN_RELEVANCE_SCORE = 0.25

SYSTEM_PROMPT = """You are a careful QA assistant answering strictly from the provided \
context chunks. Rules:
1. Only use information present in the context below. Do not use outside knowledge.
2. Every factual sentence in your answer must be followed by the id(s) of the chunk(s) \
it came from, like [chunk_id].
3. If the context does not contain enough information to answer the question, respond \
with exactly: "I don't have enough information in the provided documents to answer this." \
Do not guess or fill gaps with prior knowledge.
4. Be concise and directly answer the question."""


@dataclass
class GenerationResult:
    answer: str
    cited_chunk_ids: list[str]
    used_no_context_fallback: bool
    latency_ms: float
    input_tokens: int
    output_tokens: int
    model: str
    raw_context_chunk_ids: list[str] = field(default_factory=list)


def _build_context_block(chunks: list[RetrievedChunk]) -> str:
    parts = []
    for c in chunks:
        parts.append(f"[{c.chunk_id}] (source: {c.metadata.get('source', 'unknown')})\n{c.text}")
    return "\n\n---\n\n".join(parts)


def generate_answer(
    client: anthropic.Anthropic,
    model: str,
    question: str,
    chunks: list[RetrievedChunk],
) -> GenerationResult:
    t0 = time.perf_counter()
    relevant = [c for c in chunks if c.score >= MIN_RELEVANCE_SCORE]

    if not relevant:
        latency_ms = (time.perf_counter() - t0) * 1000
        return GenerationResult(
            answer=NO_CONTEXT_SENTINEL,
            cited_chunk_ids=[],
            used_no_context_fallback=True,
            latency_ms=latency_ms,
            input_tokens=0,
            output_tokens=0,
            model=model,
            raw_context_chunk_ids=[c.chunk_id for c in chunks],
        )

    context_block = _build_context_block(relevant)
    user_msg = f"Context:\n{context_block}\n\nQuestion: {question}"

    response = client.messages.create(
        model=model,
        max_tokens=800,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )
    latency_ms = (time.perf_counter() - t0) * 1000
    answer_text = "".join(b.text for b in response.content if b.type == "text")

    import re
    cited = sorted(set(re.findall(r"\[([a-f0-9_]{10,})\]", answer_text)))
    valid_ids = {c.chunk_id for c in relevant}
    cited = [c for c in cited if c in valid_ids]

    used_fallback = NO_CONTEXT_SENTINEL.strip(".") in answer_text

    return GenerationResult(
        answer=answer_text,
        cited_chunk_ids=cited,
        used_no_context_fallback=used_fallback,
        latency_ms=latency_ms,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        model=model,
        raw_context_chunk_ids=[c.chunk_id for c in relevant],
    )
