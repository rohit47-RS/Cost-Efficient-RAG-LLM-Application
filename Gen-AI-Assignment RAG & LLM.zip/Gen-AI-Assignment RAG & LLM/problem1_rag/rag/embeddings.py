"""
Embedding model wrapper.

Model: sentence-transformers/all-MiniLM-L6-v2
Dimensionality: 384
Why: Anthropic does not currently expose an embeddings endpoint. all-MiniLM-L6-v2 is
small (~90MB), runs on CPU in real time, and is a standard strong baseline for
sentence/paragraph embeddings — good enough to prove the RAG architecture and cost
story without requiring a second paid API. Swapping to Voyage AI or OpenAI embeddings
is a ~10-line change confined to this file (implement `embed_texts`).
"""
from __future__ import annotations
from functools import lru_cache

import numpy as np

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
EMBEDDING_DIM = 384


@lru_cache(maxsize=1)
def _get_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(MODEL_NAME)


def embed_texts(texts: list[str]) -> np.ndarray:
    """Returns an (N, 384) float32 array, L2-normalized (so cosine similarity ==
    dot product, which is what Chroma's default 'cosine' space assumes)."""
    if not texts:
        return np.zeros((0, EMBEDDING_DIM), dtype=np.float32)
    model = _get_model()
    vecs = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vecs, dtype=np.float32)


def embed_query(query: str) -> list[float]:
    return embed_texts([query])[0].tolist()
