# Shipping Policy

## Domestic Shipping
Standard domestic shipping takes 3-5 business days and costs $5.99, or is free
on orders over $50. Expedited shipping (1-2 business days) costs $14.99.

## International Shipping
International orders take 7-21 business days depending on destination and
customs processing. International shipping costs vary by weight and destination
and are calculated at checkout. Customers are responsible for any customs duties
or import taxes.

## Order Tracking
A tracking number is emailed within 24 hours of the order shipping. Tracking
information is also available on the "My Orders" page.

## Lost or Delayed Packages
If a domestic package has not arrived within 10 business days of the estimated
delivery date, customers should contact support for a replacement or refund. For
international orders, the threshold is 30 business days due to longer customs
variability.
