# Refund and Returns Policy

## Standard Refund Window
Customers may request a full refund within 30 days of the original purchase date,
provided the item is unused and in its original packaging. Refund requests made
after 30 days but within 60 days are eligible for store credit only, not a cash
refund.

## Digital Products
Digital downloads and software licenses are non-refundable once the license key
has been activated, except where required by local consumer protection law.

## Damaged or Defective Items
If an item arrives damaged or defective, customers have 90 days from delivery to
report the issue and receive a full refund or free replacement, regardless of the
standard 30-day window.

## Refund Processing Time
Approved refunds are processed within 5-7 business days and returned to the
original payment method. Store credit is issued instantly upon approval.

## How to Request a Refund
Refunds can be requested through the "My Orders" page or by emailing
support@example.com with the order number. A support agent will respond within
24 hours on business days.
