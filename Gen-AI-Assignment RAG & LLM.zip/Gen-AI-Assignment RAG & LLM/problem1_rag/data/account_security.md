# Account Security Guidelines

## Password Requirements
Passwords must be at least 10 characters and include one number and one special
character. We recommend using a password manager to generate a unique password
for this account.

## Two-Factor Authentication
Two-factor authentication (2FA) can be enabled from Account Settings > Security.
We support authenticator apps (TOTP) and SMS codes. Authenticator apps are
recommended over SMS, since SMS can be intercepted via SIM-swap attacks.

## Suspicious Activity
If you notice a login from an unrecognized device or location, immediately
change your password and revoke active sessions from Account Settings >
Security > Active Sessions. Contact support if you believe your account has
been compromised, and we will lock the account pending verification.

## Data Retention
Account data is retained for 90 days after account deletion is requested, to
allow for recovery in case of accidental deletion, after which it is
permanently purged from all systems including backups.
