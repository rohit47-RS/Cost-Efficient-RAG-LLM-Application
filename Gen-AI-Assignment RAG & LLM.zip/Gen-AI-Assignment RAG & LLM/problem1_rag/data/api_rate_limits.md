# API Rate Limits

## Default Limits
Free tier accounts are limited to 60 requests per minute and 5,000 requests per
day. Paid tier accounts are limited to 600 requests per minute and 200,000
requests per day.

## Rate Limit Headers
Every API response includes X-RateLimit-Limit, X-RateLimit-Remaining, and
X-RateLimit-Reset headers so clients can back off proactively rather than
waiting for a 429 response.

## Exceeding Limits
Requests beyond the limit receive an HTTP 429 response with a Retry-After
header indicating how many seconds to wait. Repeated abuse (sustained
violations over 24 hours) may result in temporary API key suspension.

## Requesting Higher Limits
Enterprise customers can request custom rate limits by contacting their account
manager. Custom limits typically require justifying expected peak traffic.
