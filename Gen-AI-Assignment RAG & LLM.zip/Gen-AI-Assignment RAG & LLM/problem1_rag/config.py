"""
Central config, loaded entirely from environment variables (.env).
No secrets or magic numbers are hardcoded elsewhere in the codebase.
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _get(name: str, default: str | None = None, required: bool = False) -> str:
    val = os.getenv(name, default)
    if required and not val:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return val


@dataclass(frozen=True)
class Settings:
    anthropic_api_key: str
    generation_model: str
    embedding_model: str
    chunk_size_tokens: int
    chunk_overlap_tokens: int
    chroma_persist_dir: str
    chroma_collection: str
    default_top_k: int
    log_level: str


def get_settings() -> Settings:
    return Settings(
        # Not marked required here so ingestion / offline eval steps that never call the
        # generation LLM can run without a key. generation.py raises clearly if it's missing
        # at the point a Claude call is actually attempted.
        anthropic_api_key=_get("ANTHROPIC_API_KEY", ""),
        generation_model=_get("GENERATION_MODEL", "claude-sonnet-5"),
        embedding_model=_get("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
        chunk_size_tokens=int(_get("CHUNK_SIZE_TOKENS", "350")),
        chunk_overlap_tokens=int(_get("CHUNK_OVERLAP_TOKENS", "60")),
        chroma_persist_dir=_get("CHROMA_PERSIST_DIR", "./chroma_db"),
        chroma_collection=_get("CHROMA_COLLECTION", "rag_docs"),
        default_top_k=int(_get("DEFAULT_TOP_K", "5")),
        log_level=_get("LOG_LEVEL", "INFO"),
    )
