"""
Evaluation harness. Runs the fixed question set end-to-end against the live
service (retrieval + generation), computes retrieval metrics (Recall@k, Hit Rate,
MRR, nDCG@k, context precision), answer metrics (EM/F1 against gold spans,
faithfulness/relevance via LLM-as-judge), and latency percentiles. Writes one
combined results JSON.

Usage:
    python -m eval.run_eval --top-k 5 --out results/eval_results.json

Requires the collection to already be ingested (see ingest.py) and
ANTHROPIC_API_KEY set (both for the generator and for the LLM-judge scoring).
"""
from __future__ import annotations
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import anthropic

from config import get_settings
from rag.generation import generate_answer
from rag.retrieval import retrieve
from rag.store import VectorStore
from eval.metrics import (
    hit_rate, recall_at_k, mrr, ndcg_at_k, context_precision,
    exact_match, f1_score, percentile,
)

JUDGE_SYSTEM_PROMPT = """You are grading a QA answer for a RAG system. Given the \
question, the retrieved context, and the generated answer, score two things from 1-5:

- faithfulness: is every claim in the answer actually supported by the context \
(1 = fabricates things not in context, 5 = fully grounded, no unsupported claims)?
- relevance: does the answer actually address the question (1 = off-topic/non-answer, \
5 = directly and completely answers it)?

Respond with ONLY a JSON object: {"faithfulness": <int>, "relevance": <int>, "rationale": "<one sentence>"}"""


def llm_judge_score(client: anthropic.Anthropic, model: str, question: str, context: str, answer: str) -> dict:
    user_msg = f"Question: {question}\n\nContext:\n{context}\n\nAnswer to grade:\n{answer}"
    try:
        resp = client.messages.create(
            model=model,
            max_tokens=200,
            system=JUDGE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        text = "".join(b.text for b in resp.content if b.type == "text").strip()
        text = text.strip("`").removeprefix("json").strip()
        parsed = json.loads(text)
        return {
            "faithfulness": int(parsed["faithfulness"]),
            "relevance": int(parsed["relevance"]),
            "rationale": parsed.get("rationale", ""),
        }
    except Exception as e:
        return {"faithfulness": None, "relevance": None, "rationale": f"judge_parse_error: {e}"}


def run(top_k: int, out_path: Path, questions_path: Path):
    settings = get_settings()
    store = VectorStore(settings.chroma_persist_dir, settings.chroma_collection)
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    data = json.loads(questions_path.read_text())
    questions = data["questions"]

    per_question_results = []
    retrieval_latencies, generation_latencies = [], []
    retrieval_metric_values = {"hit_rate": [], "recall_at_k": [], "mrr": [], "ndcg": [], "precision": []}
    em_scores, f1_scores = [], []
    faithfulness_scores, relevance_scores = [], []
    hallucination_count = 0
    correct_no_context_count = 0
    total_input_tokens = total_output_tokens = 0

    for q in questions:
        t0 = time.perf_counter()
        chunks = retrieve(store, q["question"], top_k)
        retrieval_latency_ms = (time.perf_counter() - t0) * 1000
        retrieval_latencies.append(retrieval_latency_ms)

        relevances = [c.metadata.get("source") in q["relevant_sources"] for c in chunks]
        num_total_relevant = len(q["relevant_sources"])  # doc-level judgment, see questions.json note

        retrieval_metric_values["hit_rate"].append(hit_rate(relevances))
        retrieval_metric_values["recall_at_k"].append(recall_at_k(relevances, num_total_relevant))
        retrieval_metric_values["mrr"].append(mrr(relevances))
        retrieval_metric_values["ndcg"].append(ndcg_at_k(relevances, k=top_k))
        retrieval_metric_values["precision"].append(context_precision(relevances))

        gen = generate_answer(client, settings.generation_model, q["question"], chunks)
        generation_latencies.append(gen.latency_ms)
        total_input_tokens += gen.input_tokens
        total_output_tokens += gen.output_tokens

        if not q["answerable"]:
            if gen.used_no_context_fallback:
                correct_no_context_count += 1
            else:
                hallucination_count += 1
        else:
            if q.get("gold_answer"):
                em_scores.append(exact_match(gen.answer, q["gold_answer"]))
                f1_scores.append(f1_score(gen.answer, q["gold_answer"]))

        context_text = "\n\n".join(c.text for c in chunks)
        judge = llm_judge_score(client, settings.generation_model, q["question"], context_text, gen.answer)
        if judge["faithfulness"] is not None:
            faithfulness_scores.append(judge["faithfulness"])
            relevance_scores.append(judge["relevance"])

        per_question_results.append({
            "id": q["id"],
            "question": q["question"],
            "answerable": q["answerable"],
            "answer": gen.answer,
            "cited_chunk_ids": gen.cited_chunk_ids,
            "used_no_context_fallback": gen.used_no_context_fallback,
            "retrieved_sources": [c.metadata.get("source") for c in chunks],
            "retrieval_latency_ms": round(retrieval_latency_ms, 2),
            "generation_latency_ms": round(gen.latency_ms, 2),
            "judge": judge,
        })
        print(f"  {q['id']}: retrieval={retrieval_latency_ms:.0f}ms gen={gen.latency_ms:.0f}ms "
              f"faithfulness={judge['faithfulness']} relevance={judge['relevance']}")

    def avg(xs):
        return sum(xs) / len(xs) if xs else None

    summary = {
        "num_questions": len(questions),
        "top_k": top_k,
        "retrieval_metrics": {k: round(avg(v), 4) for k, v in retrieval_metric_values.items()},
        "answer_metrics": {
            "exact_match": round(avg(em_scores), 4) if em_scores else None,
            "f1": round(avg(f1_scores), 4) if f1_scores else None,
            "avg_faithfulness_1to5": round(avg(faithfulness_scores), 3) if faithfulness_scores else None,
            "avg_relevance_1to5": round(avg(relevance_scores), 3) if relevance_scores else None,
            "hallucination_rate_on_unanswerable": (
                round(hallucination_count / max(hallucination_count + correct_no_context_count, 1), 4)
            ),
        },
        "latency_ms": {
            "retrieval_p50": round(percentile(retrieval_latencies, 50), 1),
            "retrieval_p95": round(percentile(retrieval_latencies, 95), 1),
            "generation_p50": round(percentile(generation_latencies, 50), 1),
            "generation_p95": round(percentile(generation_latencies, 95), 1),
        },
        "tokens": {
            "total_input_tokens": total_input_tokens,
            "total_output_tokens": total_output_tokens,
        },
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps({"summary": summary, "per_question": per_question_results}, indent=2))
    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))
    print(f"\nWritten to {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--out", type=Path, default=Path("results/eval_results.json"))
    parser.add_argument("--questions", type=Path, default=Path("eval/questions.json"))
    args = parser.parse_args()
    run(args.top_k, args.out, args.questions)
