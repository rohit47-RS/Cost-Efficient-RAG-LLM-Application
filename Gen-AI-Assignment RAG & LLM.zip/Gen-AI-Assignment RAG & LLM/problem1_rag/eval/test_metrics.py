"""Offline unit tests for eval/metrics.py — no API key or vector store needed.
Run: python -m pytest eval/test_metrics.py -v   (or: python eval/test_metrics.py)
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from eval.metrics import (
    hit_rate, recall_at_k, mrr, ndcg_at_k, context_precision,
    exact_match, f1_score, percentile,
)


def test_hit_rate():
    assert hit_rate([False, False, True]) == 1.0
    assert hit_rate([False, False, False]) == 0.0
    assert hit_rate([]) == 0.0


def test_recall_at_k():
    assert recall_at_k([True, False, False], num_total_relevant=2) == 0.5
    assert recall_at_k([True, True, False], num_total_relevant=2) == 1.0
    assert recall_at_k([False, False], num_total_relevant=0) == 1.0


def test_mrr():
    assert mrr([False, True, False]) == 0.5
    assert mrr([True, False]) == 1.0
    assert mrr([False, False]) == 0.0


def test_ndcg_perfect_order_beats_worst_order():
    perfect = ndcg_at_k([True, True, False])
    worst = ndcg_at_k([False, True, True])
    assert perfect == 1.0
    assert worst < perfect


def test_context_precision():
    assert context_precision([True, True, False, False]) == 0.5
    assert context_precision([]) == 0.0


def test_exact_match_and_f1():
    assert exact_match("The answer is 30 days.", "30 days") == 0.0  # extra words -> not EM
    assert exact_match("30 days", "30 days") == 1.0
    assert exact_match("The 30 days", "30 days") == 1.0  # article stripped by normalization
    assert f1_score("30 days", "30 days") == 1.0
    assert f1_score("it takes about 30 days total", "30 days") > 0.3
    assert f1_score("completely unrelated text", "30 days") == 0.0


def test_percentile():
    vals = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    assert percentile(vals, 50) in (50, 60)
    assert percentile(vals, 95) == 100
    assert percentile([], 50) == 0.0


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL {t.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
