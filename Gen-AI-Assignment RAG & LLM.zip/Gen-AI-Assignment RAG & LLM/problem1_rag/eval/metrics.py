"""
Retrieval and answer-quality metrics. Pure functions, unit-testable without any
network/API access (see eval/test_metrics.py).
"""
from __future__ import annotations
import math
import re
import string


# ---------------------------------------------------------------------------
# Retrieval metrics
# ---------------------------------------------------------------------------

def hit_rate(retrieved_relevances: list[bool]) -> float:
    """1 if at least one retrieved item is relevant, else 0."""
    return 1.0 if any(retrieved_relevances) else 0.0


def recall_at_k(retrieved_relevances: list[bool], num_total_relevant: int) -> float:
    """Fraction of all known-relevant items that appear in the top-k.
    If num_total_relevant is 0 (unanswerable question, nothing relevant exists),
    recall is defined as 1.0 if we correctly retrieved nothing highly relevant,
    handled by the caller — this function just does the ratio."""
    if num_total_relevant == 0:
        return 1.0
    hits = sum(1 for r in retrieved_relevances if r)
    return min(hits / num_total_relevant, 1.0)


def mrr(retrieved_relevances: list[bool]) -> float:
    """Reciprocal rank of the first relevant item (0 if none relevant)."""
    for i, r in enumerate(retrieved_relevances, start=1):
        if r:
            return 1.0 / i
    return 0.0


def ndcg_at_k(retrieved_relevances: list[bool], k: int | None = None) -> float:
    """Binary-relevance nDCG@k."""
    rels = retrieved_relevances if k is None else retrieved_relevances[:k]
    dcg = sum((1.0 if rel else 0.0) / math.log2(i + 2) for i, rel in enumerate(rels))
    ideal_rels = sorted(rels, reverse=True)
    idcg = sum((1.0 if rel else 0.0) / math.log2(i + 2) for i, rel in enumerate(ideal_rels))
    return dcg / idcg if idcg > 0 else 0.0


def context_precision(retrieved_relevances: list[bool]) -> float:
    """Fraction of retrieved chunks that are actually relevant (precision@k)."""
    if not retrieved_relevances:
        return 0.0
    return sum(1 for r in retrieved_relevances if r) / len(retrieved_relevances)


# ---------------------------------------------------------------------------
# Answer metrics (EM / F1) — standard SQuAD-style normalization
# ---------------------------------------------------------------------------

def _normalize(text: str) -> str:
    text = text.lower()
    text = "".join(ch for ch in text if ch not in string.punctuation)
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    return " ".join(text.split())


def exact_match(prediction: str, gold: str) -> float:
    return 1.0 if _normalize(prediction) == _normalize(gold) else 0.0


def f1_score(prediction: str, gold: str) -> float:
    pred_tokens = _normalize(prediction).split()
    gold_tokens = _normalize(gold).split()
    if not pred_tokens or not gold_tokens:
        return 1.0 if pred_tokens == gold_tokens else 0.0

    common: dict[str, int] = {}
    for t in pred_tokens:
        if t in gold_tokens:
            common[t] = common.get(t, 0) + 1
    num_same = 0
    gold_counts: dict[str, int] = {}
    for t in gold_tokens:
        gold_counts[t] = gold_counts.get(t, 0) + 1
    pred_counts: dict[str, int] = {}
    for t in pred_tokens:
        pred_counts[t] = pred_counts.get(t, 0) + 1
    for t, c in pred_counts.items():
        num_same += min(c, gold_counts.get(t, 0))

    if num_same == 0:
        return 0.0
    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


# ---------------------------------------------------------------------------
# Latency percentiles
# ---------------------------------------------------------------------------

def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    idx = min(int(math.ceil(p / 100 * len(s))) - 1, len(s) - 1)
    return s[max(idx, 0)]
