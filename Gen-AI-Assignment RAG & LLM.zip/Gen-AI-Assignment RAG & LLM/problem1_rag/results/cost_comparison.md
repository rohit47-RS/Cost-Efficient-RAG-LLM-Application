# Cost Comparison: Self-hosted ChromaDB vs Managed Vector DB

Assumptions are stated in `eval/cost_analysis.py`. Dimensionality=384 (all-MiniLM-L6-v2), float32 vectors, ~500 bytes/chunk metadata overhead.

| Vectors | Self-hosted ChromaDB | Managed (pod-based, e.g. Pinecone p1.x1) | Managed (serverless storage-only) |
|---|---|---|---|
| 100,000 | $12.02/mo | $70.00/mo | $0.06/mo |
| 1,000,000 | $12.19/mo | $70.00/mo | $0.63/mo |
| 10,000,000 | $13.90/mo | $700.00/mo | $6.26/mo |

**Reading this table:** the pod-based managed column is the scenario the assignment describes ("bill scales with stored vectors via always-on pods") — at 100K vectors you're paying for a full $70/mo pod you're using 10% of. The serverless managed column is more competitive at small scale since it bills storage only, but self-hosted still wins because it has no per-GB markup over raw disk and the fixed VM cost is amortized across all scales.
