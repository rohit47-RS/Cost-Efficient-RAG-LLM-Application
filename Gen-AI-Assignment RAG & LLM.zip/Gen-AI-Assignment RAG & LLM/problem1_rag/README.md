# Problem 1 — Cost-Efficient RAG Application

A QA service over a small document corpus, backed by **ChromaDB** (embedded,
self-hosted, persisted to local disk), with a full retrieval + answer + cost
evaluation harness.

## Why ChromaDB

Of the allowed options (pgvector, Qdrant, ChromaDB, LanceDB, FAISS, sqlite-vec),
ChromaDB was chosen because:
- It's **embedded and self-hosted** — no always-on managed pod, which is the entire
  cost thesis of this assignment (see `eval/cost_analysis.py`).
- It has **native metadata filtering** (`where=...`) built in, satisfying the
  "at least one metadata filter" requirement without extra plumbing (FAISS and
  sqlite-vec would need a separate metadata store bolted on).
- It has **upsert-by-id semantics**, which map directly onto the idempotent
  chunk-id design (Qdrant and pgvector also support this; Chroma was simplest to
  stand up with zero external services for a take-home).
- Trade-off acknowledged: Chroma's HNSW index is all-in-memory-per-process at
  query time and doesn't horizontally shard — see Discussion below for where this
  stops being the right choice.

## Architecture

```
data/*.{md,pdf,html}
       │  ingest.py
       ▼
rag/chunking.py  ──►  rag/embeddings.py (all-MiniLM-L6-v2, 384-dim, local)
                              │
                              ▼
                       rag/store.py (ChromaDB, idempotent upsert)
                              │
   query ──► rag/retrieval.py (top-k + metadata filter)
                              │
                              ▼
                    rag/generation.py (Claude, grounded, cited, no-hallucination)
                              │
                              ▼
                   app.py (FastAPI /query) + rag/logging_utils.py (per-query log)
```

## Setup

```bash
cd problem1_rag
pip install -r requirements.txt
cp .env.example .env        # then add your ANTHROPIC_API_KEY
```

## Step-by-step: run it

**1. Ingest the sample corpus** (4 markdown policy docs in `data/`; drop your own
PDF/HTML/MD files in there too):

```bash
python ingest.py --input data/
```

Re-run the same command any time — it's idempotent (stable chunk IDs, delete-then-
insert per document), so you never get duplicate vectors. Try running it twice and
watch the collection count in the log stay the same.

**2. Start the service:**

```bash
uvicorn app:app --reload --port 8000
```

**3. Query it:**

```bash
curl -X POST localhost:8000/query -H "Content-Type: application/json" \
  -d '{"question": "How many days do I have to request a refund?", "top_k": 5}'
```

```json
{
  "answer": "You have 30 days from the purchase date to request a full cash refund... [chunk_id]",
  "citations": [{"chunk_id": "...", "source": "refund_policy.md", "score": 0.81}],
  "used_no_context_fallback": false,
  "retrieval_latency_ms": 12.4,
  "generation_latency_ms": 890.2,
  ...
}
```

Ask something the corpus doesn't cover (e.g. "what's the CEO's name?") and you'll
get `"I don't have enough information in the provided documents to answer this."`
instead of a hallucinated answer — this is a hard threshold in `rag/generation.py`
(`MIN_RELEVANCE_SCORE`), not a hope that the model behaves.

**4. Run the offline logic tests** (no API key needed — pure functions):

```bash
python eval/test_metrics.py
```

**5. Run the full evaluation harness** (needs `ANTHROPIC_API_KEY` and an ingested
collection):

```bash
python -m eval.run_eval --top-k 5 --out results/eval_results.json
```

This runs all 22 fixed questions in `eval/questions.json` through retrieval +
generation + an LLM-judge faithfulness/relevance check, and writes a combined
results file (per-question detail + aggregate summary).

**6. Generate the cost comparison table:**

```bash
python -m eval.cost_analysis
```

Writes `results/cost_comparison.md`.

## Evaluation design

**Fixed question set** (`eval/questions.json`, 22 questions): 19 answerable
questions spanning all 4 source docs, plus 3 deliberately unanswerable questions
(paid parental leave, SDK languages, CEO's name — none of which are in the corpus)
to measure hallucination rate.

**Relevance judgments**: doc-level (a retrieved chunk counts as relevant if its
`source` metadata matches the question's `relevant_sources` list). This is a
standard simplification when hand-labeling every chunk isn't practical — it's
valid here because chunking at eval-time settings produces only 2 chunks per
source doc, so doc-level and chunk-level relevance are nearly equivalent.

**Retrieval metrics**: Hit Rate, Recall@k, MRR, nDCG@k, context precision — all
implemented from scratch in `eval/metrics.py` with offline unit tests (no
external dependency, no LLM call) in `eval/test_metrics.py`.

**Answer metrics**:
- EM/F1 against short gold spans, for questions with a crisp factual answer
  (standard SQuAD-style normalization: lowercase, strip punctuation/articles).
- Faithfulness + relevance (1-5 each) via LLM-as-judge (Claude scoring its own
  sibling call — see Problem 2 for why this has a self-enhancement bias risk;
  for this problem's scope a single-model judge is accepted, flagged as a
  limitation below).
- Hallucination rate on the 3 unanswerable questions: did the model correctly
  say "I don't know" or did it invent an answer?

**Cost & latency**: p50/p95 retrieval and generation latency come straight out
of the eval run. The cost table (`eval/cost_analysis.py`) compares self-hosted
Chroma against both a pod-based managed DB (the "always-on pods" scenario the
assignment describes) and a modern storage-billed serverless managed DB, at
100K / 1M / 10M vectors, with every assumption stated in the script.

## Results

*(Populate this section by running `eval/run_eval.py` and `eval/cost_analysis.py`
with a real `ANTHROPIC_API_KEY` — this repo ships the harness, not fabricated
numbers, since actual scores depend on the live model. The commands above write
`results/eval_results.json` and `results/cost_comparison.md`.)*

Cost table (deterministic, no API key needed — already generated, see
`results/cost_comparison.md`):

| Vectors | Self-hosted ChromaDB | Managed (pod-based) | Managed (serverless) |
|---|---|---|---|
| 100,000 | ~$12/mo | $70/mo | ~$0.06/mo |
| 1,000,000 | ~$12/mo | $70/mo | ~$0.63/mo |
| 10,000,000 | ~$14/mo | $700/mo | ~$6/mo |

## Discussion

**When would you switch back to a managed DB?**
1. **Query volume grows, not just storage.** This whole cost story assumes a
   *lightly-queried* index (the assignment's premise). If query QPS grows into
   the hundreds/thousands, you now need to horizontally scale query serving,
   handle replica consistency, and operate uptime/backup/monitoring yourself —
   that's exactly what you're paying a managed vendor for. Self-hosted wins on
   storage cost; managed wins on *operational* cost once you need real SRE work.
2. **Multi-region / high availability requirements.** Chroma's persistence is a
   local directory; getting multi-AZ failover requires you to build it (e.g.
   replicated disk, leader election), which a managed vendor gives you natively.
3. **Team without infra ownership appetite.** The self-hosted savings assume
   someone maintains the VM, disk, backups, and upgrade path. If that's not
   free (a team's time isn't), the crossover point moves earlier.
4. **Vectors scale past what fits comfortably in one node's RAM/HNSW graph**
   (roughly high tens-of-millions for this dimensionality) — Chroma doesn't
   shard automatically, so you'd need to build sharding yourself, at which
   point you're re-implementing what Pinecone/Qdrant Cloud already do.

**Was retrieval or generation the weak link?** Run `eval/run_eval.py` with a real
API key and compare `retrieval_metrics.recall_at_k` / `context_precision` against
`answer_metrics.avg_faithfulness_1to5`. In practice with a small, topically
disjoint corpus like this demo one, retrieval tends to saturate near 1.0 (the
right doc is almost always the top hit) — so any weakness usually shows up in
generation: either uncited claims (low faithfulness) or over-triggering the
no-context fallback on borderline-relevant questions (check
`hallucination_rate_on_unanswerable` and manually scan the 3 unanswerable
question transcripts).

**Known limitations**
- The LLM-judge for faithfulness/relevance uses the *same* model family as the
  generator, which risks self-enhancement bias (see Problem 2's bias-handling
  section for the proper mitigation — using a different judge model family or
  running position-swapped pairwise comparisons). For a single-app eval this is
  accepted as a scoping trade-off, not solved here.
- Chunking uses a whitespace tokenizer as an approximation of "tokens" for
  sizing purposes (documented in `rag/chunking.py`) rather than a model-specific
  BPE tokenizer, to avoid an external download dependency. Billable generation
  tokens are still exact (read from the Anthropic API's `usage` field).
- The demo corpus is intentionally small (4 short docs) so the whole pipeline
  is runnable and inspectable in minutes; the cost table extrapolates to
  100K–10M vectors mathematically rather than by actually loading that much
  data, since doing so isn't practical for a take-home.
