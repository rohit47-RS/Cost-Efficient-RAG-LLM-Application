"""
Judge validation. Implements all three checks the assignment lists:

1. Agreement with human/gold labels — agreement rate + Cohen's kappa (pass/fail)
   + Pearson correlation (scores).
2. Test-retest consistency — run the judge twice on the same cases, measure how
   often the verdict flips.
3. Adversarial probe set — verbose-but-wrong / terse-but-correct / confidently-wrong
   cases (tagged in test_suite.json), check whether the judge was fooled.

Usage:
    python -m validation.validate --out results/judge_validation.json
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import anthropic

from config import get_settings
from judge.schemas import TestSuite
from judge.judge import judge_pointwise
from judge.bias import run_verbosity_probe, run_sycophancy_probe


def cohens_kappa(labels_a: list[bool], labels_b: list[bool]) -> float:
    """Binary Cohen's kappa from first principles (no sklearn dependency)."""
    n = len(labels_a)
    if n == 0:
        return 0.0
    po = sum(1 for a, b in zip(labels_a, labels_b) if a == b) / n

    a_true_rate = sum(labels_a) / n
    b_true_rate = sum(labels_b) / n
    pe = a_true_rate * b_true_rate + (1 - a_true_rate) * (1 - b_true_rate)

    if pe == 1.0:
        return 1.0  # both raters agree trivially on everything
    return (po - pe) / (1 - pe)


def pearson_correlation(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    mean_x, mean_y = sum(xs) / n, sum(ys) / n
    cov = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    var_x = sum((x - mean_x) ** 2 for x in xs)
    var_y = sum((y - mean_y) ** 2 for y in ys)
    denom = (var_x * var_y) ** 0.5
    return cov / denom if denom > 0 else 0.0


def run_agreement_check(client, judge_model, suite: TestSuite, gold_labels: dict, pass_threshold: float) -> dict:
    judge_pass, human_pass = [], []
    judge_scores, human_scores = [], []
    details = []

    for case in suite.cases:
        gold = gold_labels.get(case.id)
        if gold is None:
            continue
        verdict = judge_pointwise(client, judge_model, case)
        j_pass = verdict.overall_score >= pass_threshold
        judge_pass.append(j_pass)
        human_pass.append(gold["human_pass"])
        judge_scores.append(verdict.overall_score)
        human_scores.append(gold["human_overall_score"])
        details.append({
            "case_id": case.id, "judge_score": verdict.overall_score, "human_score": gold["human_overall_score"],
            "judge_pass": j_pass, "human_pass": gold["human_pass"], "agree": j_pass == gold["human_pass"],
        })

    n = len(details)
    agreement_rate = sum(1 for d in details if d["agree"]) / n if n else 0.0
    kappa = cohens_kappa(judge_pass, human_pass)
    corr = pearson_correlation(judge_scores, human_scores)

    return {
        "n_labeled_cases": n, "agreement_rate": round(agreement_rate, 4),
        "cohens_kappa": round(kappa, 4), "pearson_correlation_scores": round(corr, 4),
        "details": details,
    }


def run_test_retest(client, judge_model, suite: TestSuite) -> dict:
    flips = 0
    details = []
    for case in suite.cases:
        v1 = judge_pointwise(client, judge_model, case)
        v2 = judge_pointwise(client, judge_model, case)
        pass1, pass2 = v1.overall_score >= 3.5, v2.overall_score >= 3.5
        flipped = pass1 != pass2
        flips += int(flipped)
        details.append({
            "case_id": case.id, "score_run1": v1.overall_score, "score_run2": v2.overall_score,
            "abs_score_diff": round(abs(v1.overall_score - v2.overall_score), 3), "pass_flipped": flipped,
        })
    n = len(suite.cases)
    return {
        "n_cases": n, "flip_rate": round(flips / n, 4) if n else 0.0,
        "mean_abs_score_diff": round(sum(d["abs_score_diff"] for d in details) / n, 4) if n else 0.0,
        "details": details,
    }


def run_adversarial_probes(client, judge_model, suite: TestSuite) -> dict:
    verbosity_results, sycophancy_results = [], []
    for case in suite.cases:
        tags = case.tags or []
        if "adversarial_terse_correct" in tags or case.id == "c01_correct_factual":
            verbosity_results.append(run_verbosity_probe(client, judge_model, case))
        if "adversarial_confidently_wrong" in tags:
            sycophancy_results.append(run_sycophancy_probe(client, judge_model, case))

    return {
        "verbosity_probe": {
            "n_probes": len(verbosity_results),
            "n_judge_rewarded_padding": sum(1 for r in verbosity_results if not r.passed),
            "details": [r.__dict__ for r in verbosity_results],
        },
        "sycophancy_probe": {
            "n_probes": len(sycophancy_results),
            "n_judge_fooled": sum(1 for r in sycophancy_results if r.fooled),
            "details": [r.__dict__ for r in sycophancy_results],
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite", type=Path, default=Path("test_suite.json"))
    parser.add_argument("--gold", type=Path, default=Path("validation/gold_labels.json"))
    parser.add_argument("--out", type=Path, default=Path("results/judge_validation.json"))
    args = parser.parse_args()

    settings = get_settings()
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    suite = TestSuite.model_validate(json.loads(args.suite.read_text()))
    gold_labels = json.loads(args.gold.read_text())["labels"]

    print("Running agreement check against gold labels...")
    agreement = run_agreement_check(client, settings.judge_model, suite, gold_labels, settings.pass_threshold)
    print(f"  agreement_rate={agreement['agreement_rate']} kappa={agreement['cohens_kappa']} "
          f"pearson_r={agreement['pearson_correlation_scores']}")

    print("Running test-retest consistency check...")
    retest = run_test_retest(client, settings.judge_model, suite)
    print(f"  flip_rate={retest['flip_rate']} mean_abs_score_diff={retest['mean_abs_score_diff']}")

    print("Running adversarial probes...")
    adversarial = run_adversarial_probes(client, settings.judge_model, suite)
    print(f"  verbosity: {adversarial['verbosity_probe']['n_judge_rewarded_padding']}/"
          f"{adversarial['verbosity_probe']['n_probes']} rewarded padding")
    print(f"  sycophancy: {adversarial['sycophancy_probe']['n_judge_fooled']}/"
          f"{adversarial['sycophancy_probe']['n_probes']} fooled")

    report = {"agreement": agreement, "test_retest": retest, "adversarial_probes": adversarial}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2))
    print(f"\nWritten to {args.out}")


if __name__ == "__main__":
    main()
