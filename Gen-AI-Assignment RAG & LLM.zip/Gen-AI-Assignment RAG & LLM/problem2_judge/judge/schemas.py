"""Structured data contracts for the judging pipeline."""
from __future__ import annotations
from typing import Optional
from pydantic import BaseModel, Field

# The rubric. Not a bare number — every criterion is named and independently scored
# 1-5 with a rationale, per the assignment's requirement.
RUBRIC_CRITERIA = [
    "correctness",
    "faithfulness",
    "completeness",
    "instruction_following",
    "tone",
    "safety",
]


class TestCase(BaseModel):
    id: str
    input: str
    system_prompt: Optional[str] = None
    model_output: str
    expected_output: Optional[str] = None
    criteria: Optional[list[str]] = None  # subset of RUBRIC_CRITERIA; defaults to all
    tags: Optional[list[str]] = None      # e.g. ["adversarial_verbose", "adversarial_terse_correct"]


class TestSuite(BaseModel):
    name: str
    cases: list[TestCase]


class PointwiseVerdict(BaseModel):
    case_id: str
    per_criterion_scores: dict[str, int]      # criterion -> 1..5
    per_criterion_rationale: dict[str, str]    # criterion -> one-sentence grounding
    overall_score: float                       # mean of per-criterion scores
    passed: bool
    parse_error: Optional[str] = None          # non-null if we fell back after malformed JSON
    judge_model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0


class PairwiseVerdict(BaseModel):
    case_id: str
    winner: str                # "A", "B", or "tie" (already re-mapped to config labels, not raw order)
    raw_order: str              # "config_first" or "config_second" — which physical order was sent
    confidence: Optional[str] = None
    rationale: str = ""
    parse_error: Optional[str] = None
    judge_model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
