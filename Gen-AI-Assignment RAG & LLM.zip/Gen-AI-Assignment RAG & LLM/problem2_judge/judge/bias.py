"""
Bias handling. Implements the mitigations from the assignment's bias table as
runnable code, not just documentation:

| Bias                  | Mitigation implemented here |
|------------------------|------------------------------|
| Position (A/B order)   | run_position_bias_check: judges each pair in BOTH orders, remaps back to stable labels, reports flip rate |
| Verbosity / length      | run_verbosity_probe: pads a correct terse answer with unsupported filler, checks the judge doesn't reward the padding |
| Self-enhancement        | config-level: JUDGE_MODEL is independently configurable from GENERATOR_MODEL (see config.py); this repo defaults to a different Claude tier as a partial mitigation and documents swapping in a different vendor entirely in README |
| Sycophancy / style      | run_sycophancy_probe: scores a confidently-worded but factually wrong answer and checks the judge isn't fooled by fluency |
| Score clustering        | mitigated in the prompt itself via few-shot calibration anchors (judge/prompts.py CALIBRATION_ANCHORS) |
"""
from __future__ import annotations
from dataclasses import dataclass, field

import anthropic

from judge.judge import judge_pairwise, judge_pointwise
from judge.schemas import TestCase


# ---------------------------------------------------------------------------
# Position bias
# ---------------------------------------------------------------------------

@dataclass
class PositionBiasResult:
    case_id: str
    winner_order1: str      # winner in original label-space, from the (A,B) call
    winner_order2: str      # winner in original label-space, from the (B,A) call
    flipped: bool           # True if the two orders disagreed
    final_winner: str       # order1 result if they agree, else "tie" (disagreement = no confident winner)
    total_input_tokens: int = 0   # summed across both judge calls (both orders)
    total_output_tokens: int = 0


def run_position_bias_check(
    client: anthropic.Anthropic,
    judge_model: str,
    case_id: str,
    input_text: str,
    response_a: str,
    response_b: str,
    system_prompt: str | None = None,
    expected_output: str | None = None,
) -> PositionBiasResult:
    """Runs the same pair in both physical orders and checks the judge's *label-space*
    verdict is order-independent. A judge with no position bias should pick the same
    winner (in terms of "the refund-policy version" vs "the shipping-policy version",
    not "whichever I saw first") regardless of which one it saw as 'Response A'."""
    v1 = judge_pairwise(client, judge_model, case_id, input_text, response_a, response_b,
                         system_prompt, expected_output, raw_order_label="original")
    # swapped call: what was B is now physically "Response A" and vice versa
    v2_raw = judge_pairwise(client, judge_model, case_id, input_text, response_b, response_a,
                             system_prompt, expected_output, raw_order_label="swapped")
    # remap v2's winner back into original A/B label space
    remap = {"A": "B", "B": "A", "tie": "tie"}
    winner2_remapped = remap.get(v2_raw.winner, "tie")

    flipped = v1.winner != winner2_remapped
    final_winner = v1.winner if not flipped else "tie"

    return PositionBiasResult(
        case_id=case_id, winner_order1=v1.winner, winner_order2=winner2_remapped,
        flipped=flipped, final_winner=final_winner,
        total_input_tokens=v1.input_tokens + v2_raw.input_tokens,
        total_output_tokens=v1.output_tokens + v2_raw.output_tokens,
    )


def aggregate_flip_rate(results: list[PositionBiasResult]) -> float:
    if not results:
        return 0.0
    return sum(1 for r in results if r.flipped) / len(results)


# ---------------------------------------------------------------------------
# Verbosity / length bias
# ---------------------------------------------------------------------------

_FILLER = (
    " It is worth noting that this is a broad and important topic with many facets "
    "to consider. Many experts in the field have written extensively about related "
    "matters, and there is a rich history of discussion around these kinds of "
    "questions in general."
)


def make_padded_variant(text: str, repeats: int = 2) -> str:
    """Appends generic, contentless filler (no new facts) to a correct answer, to
    probe whether the judge rewards length rather than substance."""
    return text.rstrip() + (_FILLER * repeats)


@dataclass
class VerbosityProbeResult:
    case_id: str
    original_score: float
    padded_score: float
    reward_delta: float          # padded - original; positive = judge rewarded padding (bad)
    passed: bool                 # True if the judge did NOT meaningfully reward padding


def run_verbosity_probe(client: anthropic.Anthropic, judge_model: str, case: TestCase,
                         tolerance: float = 0.25) -> VerbosityProbeResult:
    original_case = case
    padded_case = case.model_copy(update={
        "id": case.id + "_padded",
        "model_output": make_padded_variant(case.model_output),
    })

    v_orig = judge_pointwise(client, judge_model, original_case)
    v_pad = judge_pointwise(client, judge_model, padded_case)

    delta = v_pad.overall_score - v_orig.overall_score
    return VerbosityProbeResult(
        case_id=case.id, original_score=v_orig.overall_score, padded_score=v_pad.overall_score,
        reward_delta=round(delta, 3), passed=delta <= tolerance,
    )


# ---------------------------------------------------------------------------
# Sycophancy / confidently-wrong probe
# ---------------------------------------------------------------------------

@dataclass
class SycophancyProbeResult:
    case_id: str
    correctness_score: float
    faithfulness_score: float
    fooled: bool   # True if the judge scored the confidently-wrong answer highly


def run_sycophancy_probe(client: anthropic.Anthropic, judge_model: str, case: TestCase,
                          fooled_threshold: float = 3.5) -> SycophancyProbeResult:
    """`case` should be a test case tagged 'adversarial_confidently_wrong' in the test
    suite: a fluent, confident model_output that is actually factually incorrect
    relative to expected_output. A well-calibrated judge should score correctness and
    faithfulness LOW despite the confident tone."""
    verdict = judge_pointwise(client, judge_model, case)
    correctness = verdict.per_criterion_scores.get("correctness", verdict.overall_score)
    faithfulness = verdict.per_criterion_scores.get("faithfulness", verdict.overall_score)
    fooled = (correctness >= fooled_threshold) or (faithfulness >= fooled_threshold)
    return SycophancyProbeResult(
        case_id=case.id, correctness_score=correctness, faithfulness_score=faithfulness, fooled=fooled,
    )
