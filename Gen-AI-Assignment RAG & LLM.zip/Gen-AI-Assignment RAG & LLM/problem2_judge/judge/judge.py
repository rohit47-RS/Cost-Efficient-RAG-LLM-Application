"""
Calls the judge LLM and parses structured verdicts, with robust handling of
malformed JSON (models occasionally wrap JSON in prose or markdown fences despite
instructions). Every judge prompt + raw response is logged to disk for audit/replay.
"""
from __future__ import annotations
import json
import re
import time
from pathlib import Path

import anthropic

from judge.schemas import TestCase, PointwiseVerdict, PairwiseVerdict, RUBRIC_CRITERIA
from judge.prompts import (
    POINTWISE_SYSTEM_PROMPT, PAIRWISE_SYSTEM_PROMPT,
    build_pointwise_user_message, build_pairwise_user_message,
)

AUDIT_LOG_PATH = Path("logs/judge_audit.jsonl")


def _log_audit(record: dict) -> None:
    AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with AUDIT_LOG_PATH.open("a") as f:
        f.write(json.dumps(record) + "\n")


def _extract_json(text: str) -> dict:
    """Best-effort JSON extraction: strip markdown fences, then find the first
    {...} block if there's leading/trailing prose despite instructions."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
    cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(0))
    raise json.JSONDecodeError("No JSON object found", cleaned, 0)


def _call_with_retry(client: anthropic.Anthropic, model: str, system: str, user_msg: str,
                      max_tokens: int = 500):
    """Call the judge, and if the response isn't parseable JSON, make ONE retry with
    an explicit correction instruction before giving up (robust malformed-JSON handling
    without infinite-looping on a stubborn model)."""
    messages = [{"role": "user", "content": user_msg}]
    t0 = time.perf_counter()
    response = client.messages.create(model=model, max_tokens=max_tokens, system=system, messages=messages)
    text = "".join(b.text for b in response.content if b.type == "text")
    try:
        parsed = _extract_json(text)
        latency_ms = (time.perf_counter() - t0) * 1000
        return parsed, response, text, latency_ms, None
    except json.JSONDecodeError as e:
        # One corrective retry
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user", "content":
            "That was not valid JSON. Respond again with ONLY the JSON object, "
            "no markdown fences, no explanation."})
        response2 = client.messages.create(model=model, max_tokens=max_tokens, system=system, messages=messages)
        text2 = "".join(b.text for b in response2.content if b.type == "text")
        latency_ms = (time.perf_counter() - t0) * 1000
        try:
            parsed2 = _extract_json(text2)
            # combine token usage across both calls for accurate cost tracking
            response2.usage.input_tokens += response.usage.input_tokens
            response2.usage.output_tokens += response.usage.output_tokens
            return parsed2, response2, text + "\n---RETRY---\n" + text2, latency_ms, None
        except json.JSONDecodeError as e2:
            return None, response2, text + "\n---RETRY---\n" + text2, latency_ms, str(e2)


def judge_pointwise(client: anthropic.Anthropic, judge_model: str, case: TestCase) -> PointwiseVerdict:
    criteria = case.criteria or RUBRIC_CRITERIA
    user_msg = build_pointwise_user_message(
        input_text=case.input,
        model_output=case.model_output,
        system_prompt=case.system_prompt,
        expected_output=case.expected_output,
        criteria=criteria,
    )
    parsed, response, raw_text, latency_ms, error = _call_with_retry(
        client, judge_model, POINTWISE_SYSTEM_PROMPT, user_msg
    )

    _log_audit({
        "mode": "pointwise", "case_id": case.id, "judge_model": judge_model,
        "system_prompt": POINTWISE_SYSTEM_PROMPT, "user_message": user_msg,
        "raw_response": raw_text, "parse_error": error, "ts": time.time(),
    })

    if parsed is None:
        return PointwiseVerdict(
            case_id=case.id, per_criterion_scores={}, per_criterion_rationale={},
            overall_score=0.0, passed=False, parse_error=error, judge_model=judge_model,
            input_tokens=response.usage.input_tokens, output_tokens=response.usage.output_tokens,
            latency_ms=latency_ms,
        )

    scores = {k: int(v) for k, v in parsed.get("per_criterion_scores", {}).items()}
    overall = float(parsed.get("overall_score", sum(scores.values()) / max(len(scores), 1)))

    return PointwiseVerdict(
        case_id=case.id,
        per_criterion_scores=scores,
        per_criterion_rationale=parsed.get("per_criterion_rationale", {}),
        overall_score=overall,
        passed=overall >= 3.5,  # caller can re-derive with a different threshold from raw scores
        judge_model=judge_model,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        latency_ms=latency_ms,
    )


def judge_pairwise(
    client: anthropic.Anthropic,
    judge_model: str,
    case_id: str,
    input_text: str,
    response_a: str,
    response_b: str,
    system_prompt: str | None = None,
    expected_output: str | None = None,
    raw_order_label: str = "config_first",
) -> PairwiseVerdict:
    user_msg = build_pairwise_user_message(input_text, response_a, response_b, system_prompt, expected_output)
    parsed, response, raw_text, latency_ms, error = _call_with_retry(
        client, judge_model, PAIRWISE_SYSTEM_PROMPT, user_msg
    )

    _log_audit({
        "mode": "pairwise", "case_id": case_id, "judge_model": judge_model, "raw_order": raw_order_label,
        "system_prompt": PAIRWISE_SYSTEM_PROMPT, "user_message": user_msg,
        "raw_response": raw_text, "parse_error": error, "ts": time.time(),
    })

    if parsed is None:
        return PairwiseVerdict(
            case_id=case_id, winner="tie", raw_order=raw_order_label, parse_error=error,
            judge_model=judge_model, input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens, latency_ms=latency_ms,
        )

    return PairwiseVerdict(
        case_id=case_id,
        winner=parsed.get("winner", "tie"),
        raw_order=raw_order_label,
        confidence=parsed.get("confidence"),
        rationale=parsed.get("rationale", ""),
        judge_model=judge_model,
        input_tokens=response.usage.input_tokens,
        output_tokens=response.usage.output_tokens,
        latency_ms=latency_ms,
    )
