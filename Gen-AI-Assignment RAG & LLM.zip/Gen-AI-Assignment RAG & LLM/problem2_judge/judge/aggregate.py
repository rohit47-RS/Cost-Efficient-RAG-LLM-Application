"""Aggregate per-case verdicts into a suite-level report, and declare a winner
between two configs (prompt v1 vs v2, or model A vs B) from pairwise results."""
from __future__ import annotations
from judge.schemas import PointwiseVerdict, RUBRIC_CRITERIA


def aggregate_pointwise_suite(verdicts: list[PointwiseVerdict], pass_threshold: float) -> dict:
    valid = [v for v in verdicts if v.parse_error is None]
    n = len(verdicts)
    n_valid = len(valid)

    per_criterion_means: dict[str, float] = {}
    for crit in RUBRIC_CRITERIA:
        scores = [v.per_criterion_scores[crit] for v in valid if crit in v.per_criterion_scores]
        if scores:
            per_criterion_means[crit] = round(sum(scores) / len(scores), 3)

    overall_scores = [v.overall_score for v in valid]
    pass_count = sum(1 for v in valid if v.overall_score >= pass_threshold)

    return {
        "num_cases": n,
        "num_parsed_successfully": n_valid,
        "parse_failure_rate": round((n - n_valid) / n, 4) if n else 0.0,
        "pass_rate": round(pass_count / n_valid, 4) if n_valid else 0.0,
        "mean_overall_score": round(sum(overall_scores) / n_valid, 4) if n_valid else 0.0,
        "per_criterion_mean_scores": per_criterion_means,
        "total_judge_input_tokens": sum(v.input_tokens for v in verdicts),
        "total_judge_output_tokens": sum(v.output_tokens for v in verdicts),
        "total_judge_calls": n,
    }


def declare_ab_winner(win_counts: dict[str, int], tie_margin: float = 0.05) -> dict:
    """win_counts like {"A": 12, "B": 7, "tie": 3}. Declares a winner only if the win
    rate gap exceeds tie_margin (5% by default) — otherwise calls it a statistical tie
    rather than over-claiming a winner from a handful of cases."""
    total = sum(win_counts.values())
    if total == 0:
        return {"winner": "undetermined", "reason": "no comparisons run"}

    rate_a = win_counts.get("A", 0) / total
    rate_b = win_counts.get("B", 0) / total
    rate_tie = win_counts.get("tie", 0) / total

    gap = rate_a - rate_b
    if abs(gap) <= tie_margin:
        winner = "tie"
    else:
        winner = "A" if gap > 0 else "B"

    return {
        "winner": winner,
        "win_rate_A": round(rate_a, 4),
        "win_rate_B": round(rate_b, 4),
        "tie_rate": round(rate_tie, 4),
        "gap": round(gap, 4),
        "tie_margin_used": tie_margin,
        "total_comparisons": total,
    }
