"""Offline unit tests: JSON extraction, aggregation, kappa/correlation, schema loading.
None of these call the Anthropic API. Run: python judge/test_offline.py
"""
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from judge.judge import _extract_json
from judge.schemas import TestSuite, PointwiseVerdict
from judge.aggregate import aggregate_pointwise_suite, declare_ab_winner
from judge.bias import make_padded_variant, aggregate_flip_rate, PositionBiasResult
from validation.validate import cohens_kappa, pearson_correlation


def test_extract_json_clean():
    assert _extract_json('{"a": 1}') == {"a": 1}


def test_extract_json_markdown_fenced():
    assert _extract_json('```json\n{"a": 1}\n```') == {"a": 1}


def test_extract_json_with_prose_wrapper():
    text = 'Sure, here is the verdict:\n{"a": 1, "b": [1,2]}\nHope that helps!'
    assert _extract_json(text) == {"a": 1, "b": [1, 2]}


def test_extract_json_raises_on_garbage():
    try:
        _extract_json("this is not json at all")
        assert False, "should have raised"
    except json.JSONDecodeError:
        pass


def test_schema_loads_real_test_suite():
    suite_path = Path(__file__).resolve().parent.parent / "test_suite.json"
    suite = TestSuite.model_validate(json.loads(suite_path.read_text()))
    assert len(suite.cases) == 15
    assert suite.cases[0].id == "c01_correct_factual"
    ids = [c.id for c in suite.cases]
    assert len(ids) == len(set(ids)), "case ids must be unique"


def test_aggregate_pointwise_suite():
    verdicts = [
        PointwiseVerdict(case_id="a", per_criterion_scores={"correctness": 5}, per_criterion_rationale={},
                          overall_score=5.0, passed=True, judge_model="m"),
        PointwiseVerdict(case_id="b", per_criterion_scores={"correctness": 2}, per_criterion_rationale={},
                          overall_score=2.0, passed=False, judge_model="m"),
        PointwiseVerdict(case_id="c", per_criterion_scores={}, per_criterion_rationale={},
                          overall_score=0.0, passed=False, judge_model="m", parse_error="bad json"),
    ]
    summary = aggregate_pointwise_suite(verdicts, pass_threshold=3.5)
    assert summary["num_cases"] == 3
    assert summary["num_parsed_successfully"] == 2
    assert abs(summary["parse_failure_rate"] - 1 / 3) < 1e-3  # value is rounded to 4dp in aggregate_pointwise_suite
    assert summary["pass_rate"] == 0.5  # 1 of 2 valid verdicts passed


def test_declare_ab_winner_clear_win():
    result = declare_ab_winner({"A": 15, "B": 3, "tie": 2})
    assert result["winner"] == "A"


def test_declare_ab_winner_tie_within_margin():
    result = declare_ab_winner({"A": 10, "B": 9, "tie": 1})
    assert result["winner"] == "tie"


def test_padded_variant_adds_no_new_facts_only_length():
    original = "The refund window is 30 days."
    padded = make_padded_variant(original)
    assert padded.startswith(original)
    assert len(padded) > len(original) * 2


def test_position_bias_flip_rate_aggregation():
    results = [
        PositionBiasResult("c1", "A", "A", flipped=False, final_winner="A"),
        PositionBiasResult("c2", "A", "B", flipped=True, final_winner="tie"),
        PositionBiasResult("c3", "B", "B", flipped=False, final_winner="B"),
        PositionBiasResult("c4", "A", "B", flipped=True, final_winner="tie"),
    ]
    assert aggregate_flip_rate(results) == 0.5


def test_cohens_kappa_perfect_agreement():
    a = [True, False, True, True, False]
    b = [True, False, True, True, False]
    assert cohens_kappa(a, b) == 1.0


def test_cohens_kappa_chance_agreement_near_zero():
    # 4/4 true vs alternating -> agreement happens to be 50%, but with a's marginal
    # rate at 100%, expected agreement by chance is also high, so kappa should be low/undefined-ish
    a = [True, True, True, True]
    b = [True, False, True, False]
    k = cohens_kappa(a, b)
    assert k <= 0.5  # loose bound, just sanity-checking it's not claiming strong agreement


def test_pearson_correlation_perfect_positive():
    xs = [1, 2, 3, 4, 5]
    ys = [2, 4, 6, 8, 10]
    assert abs(pearson_correlation(xs, ys) - 1.0) < 1e-9


def test_pearson_correlation_no_relationship():
    xs = [1, 2, 3, 4, 5]
    ys = [3, 3, 3, 3, 3]
    assert pearson_correlation(xs, ys) == 0.0


def test_gold_labels_align_with_test_suite():
    root = Path(__file__).resolve().parent.parent
    suite = json.loads((root / "test_suite.json").read_text())
    gold = json.loads((root / "validation" / "gold_labels.json").read_text())["labels"]
    suite_ids = {c["id"] for c in suite["cases"]}
    gold_ids = set(gold.keys())
    assert gold_ids.issubset(suite_ids), f"gold labels reference unknown case ids: {gold_ids - suite_ids}"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
        except Exception as e:
            failed += 1
            print(f"FAIL {t.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
